package com.example.pj_lab11;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import Adapter.FoodAdapter;
import Model.Food;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    FoodAdapter foodAdapter;
    List<Food> foodList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize the product list
        foodList = new ArrayList<>();
        foodList.add(new Food("กะเพราหมูโคตรกรอบบฟันเเตก", "ผัด", 60, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTg8ofdDykGOGrX2TG4z8RT9aAhL6jwXx3bqg&s"));
        foodList.add(new Food("เเกงส้มใต้เเท้ๆ", "เเกง", 70, "https://mpics.mgronline.com/pics/Images/566000004578002.JPEG"));

        foodAdapter = new FoodAdapter(this, foodList);
        recyclerView.setAdapter(foodAdapter);
    }
}